Instrucciones:

 1) Bajar datos de Casen 2022 y ubicarlos en la carpeta data: https://observatorio.ministeriodesarrollosocial.gob.cl/encuesta-casen-2022
 
 2) Poner masterfile en forma
 3) Realizar instrucciones señaladas en los diferentes archivos de código (Carpeta code)
 4) Ejecutar la totalidad del proyecto desde el masterfile
 5) Chequear que se hayan creador los resultados esperados.