
#################### Manipulates data #################### 



# visualiza propiedades de tus datos





# crea tabla una tabla de contingencia





print("================ EXPLORACIÓN LISTA !!!! ====================") # Debugging flags


