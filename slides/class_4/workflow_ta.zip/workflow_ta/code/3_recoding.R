
# Seleccionar subset de variables de interés  y guardarlos en nuevo objeto 



# filtra filas que cumplan una condición lógica de tu elección (ej, personas mayores de 25 años)
# reemplaza el objeto creado anteriormente con la nueva subbase de datos

# crea una nueva variable



# recodifica una variable existente




print("================ RECODIFICACIÓN LISTA !!!! ====================") # Debugging flags

